#include <iostream>
#include <bitset>

using namespace std;

int main() {
    int a;

    cout << "Introduzca un número entero." <<endl;
    cin >> a;

    cout << "El número introducido es: " << a <<endl;
    return 0;
}