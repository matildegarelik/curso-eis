#include <cmath>
#include <iostream>

using namespace std;


int main()
{
    /***************
     * esta librería tiene muchisimas operaciones,
     * de lo que quieran, practicamente.
     ***************/

    double a = M_PI;

    cout<< "a vale:" << a << ", su seno es: ";
    cout<< sin(a)<<", y su coseno: "<<cos(a)<<endl;


    return 0;
}
