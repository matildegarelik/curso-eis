#include <iostream>

using namespace std;

int main()
{

    double a, b;

    cout << "Introduzca dos numeros." << endl;

    cin >> a >> b;

    cout << "La suma es: " << a + b << endl;

    cout << "La resta es: " << a - b << endl;

    cout << "Su producto es: " << a * b << endl;

    cout << "La division entera es: " << a / b << endl;

    cout << "La division de punto flotante es: " << a * 1. / b << endl;

    /*cout << "El caracter asociado a el primer numero es: " << (char)a << endl;*/

    return 0;
}